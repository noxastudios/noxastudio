import discord
from discord.ext import commands, tasks
from discord import app_commands
import sqlite3
import random
import asyncio
import datetime
import sys

# ==============================================================================
# CONFIGURATION & CONSTANTS (AYARLAR VE SABİTLER)
# ==============================================================================

DB_NAME = "sunucu_database.db"

# Sunucunuza özel ID'ler (Lütfen kendi sunucunuzun ID'leri ile değiştirin)
KAYIT_ROL_ID = 1561164628363448391       # Kayıt tamamlandığında verilecek rol
DESTEK_KATEGORI_ID = 1558845487321190491 # Destek kanallarının açılacağı kategori
YETKILI_ROL_ID = 1561163515425718324,1558842745513185342,1561163277051109407,1562156355136262144    # Destek biletlerini görebilecek yetkili rolü
CREATE_CHANNEL_ID = 1558842445087637650  # "Oda Oluştur" ses kanalının ID'si
MOD_LOG_KANAL_ID = 1558844139653701827   # Moderasyon işlem log kanalı


# ==============================================================================
# DATABASE MANAGER (SENKRON SQLITE YARDIMCISI)
# ==============================================================================

def db_execute(query: str, params: tuple = ()):
    """Veritabanına yazma/güncelleme sorguları çalıştırır."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    conn.close()

def db_fetch_one(query: str, params: tuple = ()):
    """Veritabanından tek satır veri çeker."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(query, params)
    row = cursor.fetchone()
    conn.close()
    return row

def db_fetch_all(query: str, params: tuple = ()):
    """Veritabanından tüm uyan verileri çeker."""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute(query, params)
    rows = cursor.fetchall()
    conn.close()
    return rows


def init_db():
    """Tüm veritabanı tablolarını ilklendirir."""
    db_execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER,
            guild_id INTEGER,
            xp INTEGER DEFAULT 0,
            level INTEGER DEFAULT 1,
            bakiye INTEGER DEFAULT 100,
            daily_cooldown TEXT,
            PRIMARY KEY (user_id, guild_id)
        )
    """)
    db_execute("""
        CREATE TABLE IF NOT EXISTS tickets (
            channel_id INTEGER PRIMARY KEY,
            user_id INTEGER,
            guild_id INTEGER,
            created_at TEXT,
            status TEXT DEFAULT 'OPEN'
        )
    """)
    db_execute("""
        CREATE TABLE IF NOT EXISTS infractions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            guild_id INTEGER,
            moderator_id INTEGER,
            reason TEXT,
            type TEXT,
            timestamp TEXT
        )
    """)
    print("💾 SQLite veritabanı doğrulandı ve hazırlandı.")


# ==============================================================================
# BOT INITIALIZATION & CORE CLASS
# ==============================================================================

class AdvancedBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.voice_states = True
        intents.guilds = True

        super().__init__(
            command_prefix="!",
            intents=intents,
            help_command=None
        )
        self.active_rooms = []
        self.synced = False  # Çift komut oluşmasını engelleyen kilit anahtarı

    async def setup_hook(self):
        # 1. Veritabanını Başlat
        init_db()

        # 2. Kalıcı View'ları Kaydet (Bot yeniden başlasa da butonlar çalışır)
        self.add_view(KayitView())
        self.add_view(DestekAcView())

        # 3. Arka plan görevini başlat
        self.status_loop.start()

    @tasks.loop(minutes=5)
    async def status_loop(self):
        statuses = [
            "KIRAATHANE | OYUN & SOHBET"
        ]
        chosen = random.choice(statuses)
        await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=chosen))

    @status_loop.before_loop
    async def before_status_loop(self):
        await self.wait_until_ready()

    async def on_ready(self):
        # Sadece 1 kere senkronize et (Çift çıkma problemini kesin çözen yapı)
        if not self.synced:
            await self.tree.sync()
            self.synced = True
            print("⚡ Slash (/) komutları başarıyla tekil olarak senkronize edildi.")

        print("==================================================")
        print(f"🤖 Bot Aktif: {self.user.name}")
        print(f"🆔 Bot ID: {self.user.id}")
        print(f"🌐 Bağlı Sunucu Sayısı: {len(self.guilds)}")
        print("==================================================")


bot = AdvancedBot()


# ==============================================================================
# HELPER FUNCTIONS (YARDIMCI FONKSİYONLAR)
# ==============================================================================

async def log_to_channel(guild: discord.Guild, embed: discord.Embed):
    channel = guild.get_channel(MOD_LOG_KANAL_ID)
    if channel:
        await channel.send(embed=embed)


def add_infraction(user_id: int, guild_id: int, moderator_id: int, reason: str, infraction_type: str):
    db_execute(
        "INSERT INTO infractions (user_id, guild_id, moderator_id, reason, type, timestamp) VALUES (?, ?, ?, ?, ?, ?)",
        (user_id, guild_id, moderator_id, reason, infraction_type, str(datetime.datetime.now()))
    )


# ==============================================================================
# 1. BUTONLU KAYIT SİSTEMİ
# ==============================================================================

class KayitView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Kayıt Ol ve Kuralları Kabul Et",
        style=discord.ButtonStyle.success,
        emoji="📝",
        custom_id="persistent_kayit_button_main"
    )
    async def kayit_ol_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = interaction.guild.get_role(KAYIT_ROL_ID)
        if not role:
            await interaction.response.send_message("❌ Kayıt rolü sistemde bulunamadı. Lütfen yöneticiye başvurun.", ephemeral=True)
            return

        if role in interaction.user.roles:
            embed = discord.Embed(
                title="⚠️ Zaten Kayıtlısınız",
                description="Hesabınızda zaten üye rolü bulunuyor.",
                color=discord.Color.gold()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            await interaction.user.add_roles(role)
            embed = discord.Embed(
                title="🎉 Kayıt İşlemi Başarılı!",
                description=f"Hoş geldin {interaction.user.mention}! Sunucudaki **{role.name}** rolü hesabına tanımlandı.",
                color=discord.Color.brand_green()
            )
            embed.set_thumbnail(url=interaction.user.display_avatar.url)
            embed.set_footer(text=f"{interaction.guild.name} Güvenlik Sistemi")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("❌ Botun rol verme yetkisi yetersiz. Lütfen botun rol sırasını kontrol edin.", ephemeral=True)


@bot.tree.command(name="kayit-kur", description="Kayıt panelini bulunduğunuz kanala veya belirtilen kanala kurar.")
@app_commands.checks.has_permissions(administrator=True)
async def kayit_kur(interaction: discord.Interaction, kanal: discord.TextChannel = None):
    target_channel = kanal or interaction.channel

    embed = discord.Embed(
        title="🔒 Sunucu Doğrulama ve Kayıt Paneli",
        description=(
            "Sunucumuza hoş geldiniz!\n\n"
            "Aşağıdaki **Kayıt Ol** butonuna basarak sunucu kurallarını okuduğunuzu, "
            "kabul ettiğinizi beyan eder ve sunucudaki üye rolünü alırsınız.\n\n"
            "📜 **Genel Kurallar:**\n"
            "1. Sunucu içi küfür, hakaret ve nefret söylemi yasaktır.\n"
            "2. Din, ırk, siyaset sohbetleri ve tartışmaları yasaktır.\n"
            "3. Reklam ve spam yapmak kesinlikle yasaktır."
        ),
        color=discord.Color.blue()
    )
    embed.set_footer(text=f"{interaction.guild.name} Yönetimi", icon_url=interaction.guild.icon.url if interaction.guild.icon else None)

    await target_channel.send(embed=embed, view=KayitView())
    await interaction.response.send_message(f"✅ Kayıt paneli {target_channel.mention} kanalına başarıyla kuruldu.", ephemeral=True)


# ==============================================================================
# 2. GELİŞMİŞ DESTEK (TICKET) SİSTEMİ
# ==============================================================================

class DestekKapatView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Talebi Kapat", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="destek_kapat_btn")
    async def destek_kapat(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("⚠️ Destek talebi kapatılıyor... Kanal 5 saniye içinde silinecektir.")

        db_execute("UPDATE tickets SET status = 'CLOSED' WHERE channel_id = ?", (interaction.channel.id,))
        await asyncio.sleep(5)
        await interaction.channel.delete()

    @discord.ui.button(label="Kullanıcı Ekle", style=discord.ButtonStyle.secondary, emoji="👤", custom_id="destek_ekle_btn")
    async def kullanici_ekle(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Lütfen kanala eklemek istediğiniz kullanıcıyı `@kullanici` şeklinde etiketleyin.", ephemeral=True)


class DestekAcView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Destek Talebi Oluştur", style=discord.ButtonStyle.primary, emoji="🎫", custom_id="destek_olustur_btn")
    async def destek_olustur(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        kategori = guild.get_channel(DESTEK_KATEGORI_ID)
        yetkili_rol = guild.get_role(YETKILI_ROL_ID)

        # Kullanıcının zaten açık bir talebi var mı kontrol et
        existing = db_fetch_one("SELECT channel_id FROM tickets WHERE user_id = ? AND status = 'OPEN'", (interaction.user.id,))
        if existing:
            existing_channel = guild.get_channel(existing[0])
            if existing_channel:
                await interaction.response.send_message(f"⚠️ Zaten açık bir destek talebiniz bulunuyor: {existing_channel.mention}", ephemeral=True)
                return

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True)
        }
        if yetkili_rol:
            overwrites[yetkili_rol] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        kanal_adi = f"ticket-{interaction.user.name}".lower()
        ticket_channel = await guild.create_text_channel(
            name=kanal_adi,
            category=kategori,
            overwrites=overwrites,
            topic=f"Destek Talebi Sahibi: {interaction.user.id}"
        )

        db_execute(
            "INSERT INTO tickets (channel_id, user_id, guild_id, created_at, status) VALUES (?, ?, ?, ?, 'OPEN')",
            (ticket_channel.id, interaction.user.id, guild.id, str(datetime.datetime.now()))
        )

        embed = discord.Embed(
            title="🎫 Destek Talebi Açıldı",
            description=(
                f"Merhaba {interaction.user.mention},\n\n"
                "Destek talebiniz başarıyla oluşturuldu. Lütfen yaşadığınız sorunu "
                "detaylı bir şekilde buraya yazın. Yetkili ekibimiz en kısa sürede yanıt verecektir."
            ),
            color=discord.Color.green()
        )
        embed.set_footer(text="Talebi sonlandırmak için aşağıdaki 'Talebi Kapat' butonunu kullanabilirsiniz.")

        await ticket_channel.send(content=f"{interaction.user.mention} | {yetkili_rol.mention if yetkili_rol else ''}", embed=embed, view=DestekKapatView())
        await interaction.response.send_message(f"✅ Destek kanalınız oluşturuldu: {ticket_channel.mention}", ephemeral=True)


@bot.tree.command(name="destek-kur", description="Destek bilet panelini belirtilen kanala kurar.")
@app_commands.checks.has_permissions(administrator=True)
async def destek_kur(interaction: discord.Interaction, kanal: discord.TextChannel = None):
    target_channel = kanal or interaction.channel

    embed = discord.Embed(
        title="🛠️ Destek & Yardım Merkezi",
        description=(
            "Sunucu içi bir sorunla karşılaştıysanız veya bir konuda yardıma ihtiyacınız varsa "
            "aşağıdaki **Destek Talebi Oluştur** butonuna basarak yetkili ekibimizle özel sohbet kanalı açabilirsiniz."
        ),
        color=discord.Color.blurple()
    )
    embed.set_footer(text="Gereksiz yere talep açmak yaptırım sebebi olabilir.")

    await target_channel.send(embed=embed, view=DestekAcView())
    await interaction.response.send_message(f"✅ Destek paneli {target_channel.mention} kanalına kuruldu.", ephemeral=True)


# ==============================================================================
# 3. DETAYLI MODERASYON KOMUTLARI
# ==============================================================================

@bot.tree.command(name="ban", description="Belirtilen üyeyi sunucudan yasaklar.")
@app_commands.checks.has_permissions(ban_members=True)
async def ban(interaction: discord.Interaction, member: discord.Member, sebep: str = "Sebep Belirtilmedi"):
    if member.id == interaction.user.id:
        await interaction.response.send_message("❌ Kendinizi yasaklayamazsınız!", ephemeral=True)
        return

    if member.top_role >= interaction.user.top_role:
        await interaction.response.send_message("❌ Sizden üstün veya eşit role sahip birini yasaklayamazsınız!", ephemeral=True)
        return

    try:
        await member.ban(reason=f"{interaction.user.name}: {sebep}")
        add_infraction(member.id, interaction.guild.id, interaction.user.id, sebep, "BAN")

        embed = discord.Embed(
            title="🔨 Kullanıcı Yasaklandı",
            color=discord.Color.red(),
            timestamp=datetime.datetime.now()
        )
        embed.add_field(name="Yasaklanan Üye", value=f"{member.mention} ({member.id})", inline=False)
        embed.add_field(name="Yetkili", value=interaction.user.mention, inline=True)
        embed.add_field(name="Sebep", value=sebep, inline=True)

        await interaction.response.send_message(embed=embed)
        await log_to_channel(interaction.guild, embed)
    except Exception as e:
        await interaction.response.send_message(f"❌ İşlem başarısız oldu: {e}", ephemeral=True)


@bot.tree.command(name="unban", description="Yasaklanmış bir kullanıcının banını kaldırır.")
@app_commands.checks.has_permissions(ban_members=True)
async def unban(interaction: discord.Interaction, user_id: str):
    try:
        uid = int(user_id)
        user = await bot.fetch_user(uid)
        await interaction.guild.unban(user)

        embed = discord.Embed(
            title="🔓 Ban Kaldırıldı",
            description=f"**{user.name}** ({user.id}) adlı kullanıcının sunucu yasağı kaldırıldı.",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)
        await log_to_channel(interaction.guild, embed)
    except Exception:
        await interaction.response.send_message("❌ Kullanıcı bulunamadı veya banı kaldırılırken hata oluştu.", ephemeral=True)


@bot.tree.command(name="kick", description="Belirtilen üyeyi sunucudan atar.")
@app_commands.checks.has_permissions(kick_members=True)
async def kick(interaction: discord.Interaction, member: discord.Member, sebep: str = "Sebep Belirtilmedi"):
    if member.id == interaction.user.id:
        await interaction.response.send_message("❌ Kendinizi atamazsınız!", ephemeral=True)
        return

    if member.top_role >= interaction.user.top_role:
        await interaction.response.send_message("❌ Sizden üstün veya eşit role sahip birini atamazsınız!", ephemeral=True)
        return

    try:
        await member.kick(reason=f"{interaction.user.name}: {sebep}")
        add_infraction(member.id, interaction.guild.id, interaction.user.id, sebep, "KICK")

        embed = discord.Embed(
            title="👢 Kullanıcı Sunucudan Atıldı",
            color=discord.Color.orange(),
            timestamp=datetime.datetime.now()
        )
        embed.add_field(name="Atılan Üye", value=f"{member.mention} ({member.id})", inline=False)
        embed.add_field(name="Yetkili", value=interaction.user.mention, inline=True)
        embed.add_field(name="Sebep", value=sebep, inline=True)

        await interaction.response.send_message(embed=embed)
        await log_to_channel(interaction.guild, embed)
    except Exception as e:
        await interaction.response.send_message(f"❌ İşlem başarısız: {e}", ephemeral=True)


@bot.tree.command(name="temizle", description="Kanal içerisinden belirtilen sayıda mesajı temizler.")
@app_commands.checks.has_permissions(manage_messages=True)
async def temizle(interaction: discord.Interaction, miktar: int):
    if miktar < 1 or miktar > 100:
        await interaction.response.send_message("❌ Lütfen 1 ile 100 arasında bir sayı giriniz.", ephemeral=True)
        return

    deleted = await interaction.channel.purge(limit=miktar)
    embed = discord.Embed(
        title="🧹 Mesajlar Temizlendi",
        description=f"Bu kanaldan **{len(deleted)}** adet mesaj silindi.",
        color=discord.Color.teal()
    )
    await interaction.response.send_message(embed=embed, ephemeral=True)


@bot.tree.command(name="timeout", description="Kullanıcıya süreli susturma (mute/zamanaşımı) uygular.")
@app_commands.checks.has_permissions(moderate_members=True)
async def timeout(interaction: discord.Interaction, member: discord.Member, dakika: int, sebep: str = "Sebep Belirtilmedi"):
    if member.top_role >= interaction.user.top_role:
        await interaction.response.send_message("❌ Yetkisi sizden yüksek/eşit olan birine zamanaşımı uygulayamazsınız.", ephemeral=True)
        return

    duration = datetime.timedelta(minutes=dakika)
    await member.timeout(duration, reason=sebep)
    add_infraction(member.id, interaction.guild.id, interaction.user.id, sebep, f"TIMEOUT_{dakika}M")

    embed = discord.Embed(
        title="🔇 Zamanaşımı Uygulandı",
        color=discord.Color.dark_grey(),
        timestamp=datetime.datetime.now()
    )
    embed.add_field(name="Kullanıcı", value=member.mention, inline=True)
    embed.add_field(name="Süre", value=f"{dakika} Dakika", inline=True)
    embed.add_field(name="Sebep", value=sebep, inline=False)

    await interaction.response.send_message(embed=embed)
    await log_to_channel(interaction.guild, embed)


@bot.tree.command(name="untimeout", description="Kullanıcının zamanaşımını kaldırır.")
@app_commands.checks.has_permissions(moderate_members=True)
async def untimeout(interaction: discord.Interaction, member: discord.Member):
    await member.timeout(None)
    await interaction.response.send_message(f"🔊 {member.mention} kullanıcısının zamanaşımı kaldırıldı.")


@bot.tree.command(name="sicil", description="Bir kullanıcının ceza geçmişini görüntüler.")
@app_commands.checks.has_permissions(moderate_members=True)
async def sicil(interaction: discord.Interaction, member: discord.Member):
    rows = db_fetch_all("SELECT moderator_id, reason, type, timestamp FROM infractions WHERE user_id = ? AND guild_id = ?", (member.id, interaction.guild.id))

    if not rows:
        await interaction.response.send_message(f"ℹ️ {member.mention} kullanıcısının temiz bir sicili var.", ephemeral=True)
        return

    embed = discord.Embed(
        title="📜 Kullanıcı Sicil Kaydı",
        description=f"**{member.name}** kullanıcısına ait geçmiş cezalar:",
        color=discord.Color.dark_red()
    )

    for row in rows[-10:]:
        mod = interaction.guild.get_member(row[0])
        mod_str = mod.mention if mod else f"ID: {row[0]}"
        embed.add_field(
            name=f"[{row[2]}] - {row[3][:16]}",
            value=f"**Yetkili:** {mod_str}\n**Sebep:** {row[1]}",
            inline=False
        )

    await interaction.response.send_message(embed=embed)


# ==============================================================================
# 4. KAPSAMLI EĞLENCE & OYUN KOMUTLARI
# ==============================================================================

@bot.tree.command(name="duello", description="Etiketlediğiniz kullanıcıyla kılıçları çekip düello yaparsınız.")
async def duello(interaction: discord.Interaction, rakip: discord.Member):
    if rakip.id == interaction.user.id:
        await interaction.response.send_message("❌ Kendinizle düello edemezsiniz!", ephemeral=True)
        return
    if rakip.bot:
        await interaction.response.send_message("🤖 Botlarla düello edemezsiniz!", ephemeral=True)
        return

    embed = discord.Embed(
        title="⚔️ DÜELLO BAŞLADI!",
        description=f"{interaction.user.mention} ile {rakip.mention} karşı karşıya geliyor...\nKılıçlar çekildi!",
        color=discord.Color.gold()
    )
    await interaction.response.send_message(embed=embed)

    await asyncio.sleep(3)
    kazanan = random.choice([interaction.user, rakip])

    sonuc = discord.Embed(
        title="🏆 DÜELLO SONUÇLANDI!",
        description=f"Kıyasıya geçen mücadelenin galibi: **{kazanan.mention}** oldu! 🎉",
        color=discord.Color.green()
    )
    await interaction.channel.send(embed=sonuc)


@bot.tree.command(name="slot", description="Slot makinesini döndürürsünüz.")
async def slot(interaction: discord.Interaction):
    emojiler = ["🎰", "🍒", "🍋", "🔔", "💎", "7️⃣"]
    a = random.choice(emojiler)
    b = random.choice(emojiler)
    c = random.choice(emojiler)

    if a == b == c:
        durum = "🎉 **BÜYÜK İKRAMİYE! JACKPOT KAZANDINIZ!** 🎉"
        renk = discord.Color.green()
    elif a == b or b == c or a == c:
        durum = "✨ **Tebrikler, Çift Eşleşme Kazandınız!**"
        renk = discord.Color.gold()
    else:
        durum = "💔 **Maalesef kaybettiniz, şansınızı tekrar deneyin!**"
        renk = discord.Color.red()

    embed = discord.Embed(
        title="🎰 Slot Makinesi",
        description=f"┌───────────┐\n  │ {a} | {b} | {c} │\n└───────────┘\n\n{durum}",
        color=renk
    )
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="8ball", description="Sihirli 8-Ball sorunuza cevap verir.")
async def eightball(interaction: discord.Interaction, soru: str):
    cevaplar = [
        "Evet, kesinlikle!",
        "Kuşkusuz öyle.",
        "Büyük olasılıkla evet.",
        "Görünüşe göre evet.",
        "Pek emin değilim, tekrar dene.",
        "Daha sonra tekrar sor.",
        "Şimdi söylemesem daha iyi.",
        "Cevabım hayır.",
        "Pek sanmıyorum.",
        "Kesinlikle hayır!"
    ]
    embed = discord.Embed(title="🎱 Sihirli 8-Ball", color=discord.Color.purple())
    embed.add_field(name="Soru", value=soru, inline=False)
    embed.add_field(name="Cevap", value=random.choice(cevaplar), inline=False)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="avatar", description="Bir üyenin profil resmini büyütür.")
async def avatar(interaction: discord.Interaction, üye: discord.Member = None):
    target = üye or interaction.user
    embed = discord.Embed(
        title=f"🖼️ {target.name} Profil Resmi",
        color=discord.Color.blue()
    )
    embed.set_image(url=target.display_avatar.url)
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="yazı-tura", description="Yazı tura atarsınız.")
async def yazi_tura(interaction: discord.Interaction):
    sonuc = random.choice(["Yazı 🪙", "Tura 🪙"])
    await interaction.response.send_message(f"🪙 Para havaya atıldı ve... **{sonuc}** geldi!")


# ==============================================================================
# 5. EKONOMİ & SEVİYE (XP) SİSTEMİ
# ==============================================================================

@bot.event
async def on_message(message):
    if message.author.bot or not message.guild:
        return

    row = db_fetch_one("SELECT xp, level, bakiye FROM users WHERE user_id = ? AND guild_id = ?", (message.author.id, message.guild.id))

    if not row:
        db_execute("INSERT INTO users (user_id, guild_id, xp, level, bakiye) VALUES (?, ?, 10, 1, 100)", (message.author.id, message.guild.id))
    else:
        current_xp, current_level, current_bakiye = row
        added_xp = random.randint(5, 15)
        new_xp = current_xp + added_xp
        needed_xp = current_level * 100

        if new_xp >= needed_xp:
            new_level = current_level + 1
            new_xp -= needed_xp
            db_execute("UPDATE users SET xp = ?, level = ? WHERE user_id = ? AND guild_id = ?", (new_xp, new_level, message.author.id, message.guild.id))

            embed = discord.Embed(
                title="🎉 SEVİYE ATLADIN!",
                description=f"Tebrikler {message.author.mention}! **{new_level}. Seviyeye** ulaştın!",
                color=discord.Color.gold()
            )
            await message.channel.send(embed=embed)
        else:
            db_execute("UPDATE users SET xp = ? WHERE user_id = ? AND guild_id = ?", (new_xp, message.author.id, message.guild.id))

    await bot.process_commands(message)


@bot.tree.command(name="rank", description="Mevcut seviye, XP ve coin bakiyenizi görüntüler.")
async def rank(interaction: discord.Interaction, üye: discord.Member = None):
    target = üye or interaction.user
    row = db_fetch_one("SELECT xp, level, bakiye FROM users WHERE user_id = ? AND guild_id = ?", (target.id, interaction.guild.id))

    xp, level, bakiye = row if row else (0, 1, 100)
    needed_xp = level * 100

    embed = discord.Embed(title=f"📊 {target.name} Profil & İstatistikler", color=discord.Color.brand_green())
    embed.set_thumbnail(url=target.display_avatar.url)
    embed.add_field(name="Seviye (Level)", value=f"**{level}**", inline=True)
    embed.add_field(name="XP İlerlemesi", value=f"**{xp} / {needed_xp}**", inline=True)
    embed.add_field(name="Bakiye", value=f"💰 **{bakiye} Coin**", inline=False)

    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="gunluk", description="Günlük ücretsiz coin ödülünüzü alırsınız.")
async def gunluk(interaction: discord.Interaction):
    user_id, guild_id = interaction.user.id, interaction.guild.id
    today_str = str(datetime.date.today())

    row = db_fetch_one("SELECT daily_cooldown, bakiye FROM users WHERE user_id = ? AND guild_id = ?", (user_id, guild_id))

    if row and row[0] == today_str:
        await interaction.response.send_message("❌ Günlük ödülünüzü zaten bugün aldınız! Yarın tekrar gelin.", ephemeral=True)
        return

    odul = 250
    if not row:
        db_execute("INSERT INTO users (user_id, guild_id, xp, level, bakiye, daily_cooldown) VALUES (?, ?, 0, 1, ?, ?)", (user_id, guild_id, 100 + odul, today_str))
    else:
        db_execute("UPDATE users SET bakiye = bakiye + ?, daily_cooldown = ? WHERE user_id = ? AND guild_id = ?", (odul, today_str, user_id, guild_id))

    embed = discord.Embed(
        title="💰 Günlük Ödül Toplandı!",
        description=f"Hesabınıza **{odul} Coin** eklendi. Yarın tekrar ödül alabilirsiniz!",
        color=discord.Color.gold()
    )
    await interaction.response.send_message(embed=embed)


@bot.tree.command(name="para-transfer", description="Başka bir kullanıcıya coin gönderirsiniz.")
async def para_transfer(interaction: discord.Interaction, alici: discord.Member, miktar: int):
    if miktar <= 0:
        await interaction.response.send_message("❌ Geçersiz miktar!", ephemeral=True)
        return
    if alici.id == interaction.user.id or alici.bot:
        await interaction.response.send_message("❌ Kendinize veya botlara transfer yapamazsınız!", ephemeral=True)
        return

    row = db_fetch_one("SELECT bakiye FROM users WHERE user_id = ? AND guild_id = ?", (interaction.user.id, interaction.guild.id))
    bakiye = row[0] if row else 100

    if bakiye < miktar:
        await interaction.response.send_message("❌ Hesabınızda yeterli bakiye bulunmuyor!", ephemeral=True)
        return

    db_execute("UPDATE users SET bakiye = bakiye - ? WHERE user_id = ? AND guild_id = ?", (miktar, interaction.user.id, interaction.guild.id))
    db_execute("UPDATE users SET bakiye = bakiye + ? WHERE user_id = ? AND guild_id = ?", (miktar, alici.id, interaction.guild.id))

    await interaction.response.send_message(f"💸 {interaction.user.mention}, {alici.mention} kullanıcısına **{miktar} Coin** başarıyla gönderdi!")


# ==============================================================================
# 6. DİNAMİK ÖZEL SES KANAL SİSTEMİ
# ==============================================================================

@bot.event
async def on_voice_state_update(member, before, after):
    # Giriş yapılan kanal 'Oda Oluştur' kanalı ise
    if after.channel and after.channel.id == CREATE_CHANNEL_ID:
        guild = member.guild
        category = after.channel.category

        # Yeni özel kanal oluştur
        new_channel = await guild.create_voice_channel(
            name=f"🔊 {member.name}'in Odası",
            category=category,
            user_limit=5
        )

        # İzinleri ayarla
        await new_channel.set_permissions(member, connect=True, speak=True, manage_channels=True)

        # Üyeyi yeni odaya taşı
        await member.move_to(new_channel)
        bot.active_rooms.append(new_channel.id)

    # Odadan ayrılma kontrolü (Eğer özel odaysa ve kimse kalmadıysa sil)
    if before.channel and before.channel.id in bot.active_rooms:
        if len(before.channel.members) == 0:
            bot.active_rooms.remove(before.channel.id)
            try:
                await before.channel.delete()
            except discord.NotFound:
                pass


# ==============================================================================
# 7. GENEL BOT KOMUTLARI & HATA YAKALAMA
# ==============================================================================

@bot.tree.command(name="ping", description="Botun gecikme süresini (ping) ölçer.")
async def ping(interaction: discord.Interaction):
    latency = round(bot.latency * 1000)
    await interaction.response.send_message(f"🏓 Pong! Bot Gecikmesi: **{latency}ms**")


@bot.tree.command(name="sunucu-bilgi", description="Sunucu hakkında detaylı bilgi verir.")
async def sunucu_bilgi(interaction: discord.Interaction):
    guild = interaction.guild
    embed = discord.Embed(title=f"🏰 {guild.name} Sunucu Bilgileri", color=discord.Color.blue())
    if guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    embed.add_field(name="Sunucu Sahibi", value=guild.owner.mention if guild.owner else "Bilinmiyor", inline=True)
    embed.add_field(name="Üye Sayısı", value=str(guild.member_count), inline=True)
    embed.add_field(name="Kanal Sayısı", value=str(len(guild.channels)), inline=True)
    embed.add_field(name="Rol Sayısı", value=str(len(guild.roles)), inline=True)
    embed.add_field(name="Oluşturulma Tarihi", value=guild.created_at.strftime("%d/%m/%Y %H:%M"), inline=False)

    await interaction.response.send_message(embed=embed)


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.MissingPermissions):
        await interaction.response.send_message("🚫 Bu komutu kullanmak için gerekli yetkilere sahip değilsiniz!", ephemeral=True)
    else:
        print(f"Hata: {error}", file=sys.stderr)
        if not interaction.response.is_done():
            await interaction.response.send_message("❌ İşlem gerçekleştirilirken bilinmeyen bir hata oluştu.", ephemeral=True)


# ==============================================================================
# MAIN ENTRY POINT
# ==============================================================================

if __name__ == "__main__":
    TOKEN = "MTUyNzg4Mzg1NjgyMzQ1NTkwNQ.GR7UkE.MTghlScSNRy94ZGgfPoI7rUxdfx_EDT-moviXw"
    
    if TOKEN == "BURAYA_BOT_TOKEN_YAZIN":
        print("⚠️ HATA: Lütfen TOKEN alanına bot tokeninizi girin!")
    else:
        bot.run(TOKEN)